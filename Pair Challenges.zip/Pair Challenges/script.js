// Write a function within a function taking a random array
// Returning 2 new arrays indicating whether the numbers are odd/even


let numberArray = [2, 4, 7, 11, 15, 16];
    
function numberSort(arr){
    let evenNumber;
    let oddNumber;
    for (i = 0; i < arr.length, i++;){
        if (arr[i] % 2 === 0){
         evenNumber = evenNumber.push(arr[i])
           return evenNumber
        }
        else {
         oddNumber =  oddNumber.push(arr[i])
            return oddNumber
        }
    }
}

console.log("========================")



let vowel = ["a", "e", "i", "o","u"];

function vowelChecker(x){
    if (vowel.includes(x)){
        return "This is a vowel"
    }else if(x == "y"){
        return "This is sometimes a vowel"
    }
    else {
        return "This is not a vowel"
    }
}


console.log("=============================")


function anagrams(firstString, secondString){
    let firstStringJoined = firstString.split("").join("").sort();
    console.log(firstStringSorted.pop(" "))
    let secondStringJoined = secondString.split("").join("").sort();
    console.log(firstStringSorted)
    console.log(secondStringSorted)
    if (firstStringSorted == secondStringSorted){
        return true;
    }
    else {
        return false;
    }
}


console.log("=================================")
